import{r as e}from"./rolldown-runtime-Dw2cE7zH.js";import{i as t,r as n}from"./auth-DbeaZVwh.js";import{n as r,o as i}from"./router-C-81N8_k.js";import{n as a}from"./ui-C1SOA_s5.js";import{Lt as o,Tt as s,_t as c,at as l,dt as u,ft as d,j as f,lt as p,mt as m,pt as h,ut as g,vt as _,yt as v,z as y}from"./mui-hyJLx8Gp.js";import{t as b}from"./api-DQz6Bqs2.js";import{n as x}from"./AuthContext-BUPl1ma5.js";var S=e(t(),1),C=o(),w=`631573681169-5c6j1gmko7cbrm1uce7uuqo5bi7bkkid.apps.googleusercontent.com`;function T(){let{googleAuth:e}=x(),t=i(),r=n({onSuccess:async n=>{try{let r=await e(n.access_token);a.success(`Google ile kayıt başarılı!`),t(r.role===`admin`?`/admin`:`/menu`)}catch(e){a.error(e.response?.data?.error||`Google kayıt hatası`)}},onError:()=>a.error(`Google kayıt hatası`)});return(0,C.jsx)(_,{fullWidth:!0,variant:`outlined`,startIcon:(0,C.jsx)(f,{}),onClick:()=>r(),sx:{color:`#333`,borderColor:`#ddd`,fontWeight:600,py:1.2},children:`Google ile Kayıt Ol`})}function E(){let[e,t]=(0,S.useState)({first_name:``,last_name:``,email:``,phone:``,password:``,password2:``}),[n,o]=(0,S.useState)(!1),[f,E]=(0,S.useState)(!1),[D,O]=(0,S.useState)(!1),[k,A]=(0,S.useState)(!1),[j,M]=(0,S.useState)(!1),[N,P]=(0,S.useState)({}),{register:F}=x(),I=i();(0,S.useEffect)(()=>{b.get(`/settings`).then(e=>P(e.data)).catch(()=>{})},[]);let L=n=>t({...e,[n.target.name]:n.target.value});return(0,C.jsxs)(v,{sx:{minHeight:`calc(100vh - 100px)`,display:`flex`,alignItems:`center`,justifyContent:`center`,p:3,bgcolor:`#f5f5f5`},children:[(0,C.jsxs)(c,{sx:{p:{xs:3,md:5},width:`100%`,maxWidth:480},children:[(0,C.jsx)(s,{variant:`h5`,sx:{fontWeight:800,textAlign:`center`,mb:3.5},children:`Kayıt Ol`}),(0,C.jsxs)(`form`,{onSubmit:async t=>{if(t.preventDefault(),!e.first_name||!e.last_name||!e.email||!e.phone||!e.password){a.error(`Tüm alanları doldurunuz`);return}if(e.password!==e.password2){a.error(`Şifreler eşleşmiyor`);return}if(e.password.length<6){a.error(`Şifre en az 6 karakter olmalıdır`);return}if(!f){a.error(`KVKK Aydınlatma Metni'ni kabul etmelisiniz`);return}o(!0);try{await F({first_name:e.first_name,last_name:e.last_name,email:e.email,phone:e.phone,password:e.password}),a.success(`Kayıt başarılı!`),I(`/menu`)}catch(e){a.error(e.response?.data?.error||`Kayıt hatası`)}finally{o(!1)}},children:[(0,C.jsx)(s,{variant:`subtitle2`,sx:{fontWeight:700,mb:2,pb:1,borderBottom:`1px solid #eee`},children:`Kişisel Bilgiler`}),(0,C.jsx)(y,{fullWidth:!0,label:`İsim`,name:`first_name`,value:e.first_name,onChange:L,sx:{mb:2},size:`medium`}),(0,C.jsx)(y,{fullWidth:!0,label:`Soyisim`,name:`last_name`,value:e.last_name,onChange:L,sx:{mb:2},size:`medium`}),(0,C.jsx)(y,{fullWidth:!0,label:`E-posta`,name:`email`,type:`email`,value:e.email,onChange:L,sx:{mb:2},size:`medium`}),(0,C.jsx)(y,{fullWidth:!0,label:`Telefon Numarası`,name:`phone`,type:`tel`,value:e.phone,onChange:L,sx:{mb:2},size:`medium`}),(0,C.jsx)(y,{fullWidth:!0,label:`Şifre`,name:`password`,type:`password`,value:e.password,onChange:L,sx:{mb:2},size:`medium`}),(0,C.jsx)(y,{fullWidth:!0,label:`Şifre Tekrar`,name:`password2`,type:`password`,value:e.password2,onChange:L,sx:{mb:2},size:`medium`}),(0,C.jsx)(l,{control:(0,C.jsx)(m,{checked:f,onChange:e=>E(e.target.checked),sx:{"&.Mui-checked":{color:`#dc2626`}}}),label:(0,C.jsxs)(s,{variant:`body2`,children:[(0,C.jsx)(s,{component:`span`,onClick:e=>{e.preventDefault(),O(!0)},sx:{color:`#3b82f6`,cursor:`pointer`,fontWeight:600,textDecoration:`underline`},children:`KVKK Aydınlatma Metni`}),`,`,` `,(0,C.jsx)(s,{component:`span`,onClick:e=>{e.preventDefault(),A(!0)},sx:{color:`#3b82f6`,cursor:`pointer`,fontWeight:600,textDecoration:`underline`},children:`Gizlilik Politikası`}),` ve`,` `,(0,C.jsx)(s,{component:`span`,onClick:e=>{e.preventDefault(),M(!0)},sx:{color:`#3b82f6`,cursor:`pointer`,fontWeight:600,textDecoration:`underline`},children:`Mesafeli Satış Sözleşmesi`}),`'ni okudum, kabul ediyorum.`]}),sx:{mb:2,alignItems:`flex-start`}}),(0,C.jsx)(_,{fullWidth:!0,type:`submit`,variant:`contained`,color:`primary`,disabled:n||!f,sx:{py:1.5,fontSize:15,fontWeight:700,mt:1},children:n?`Kayıt yapılıyor...`:`Kayıt Ol`})]}),w!==`YOUR_GOOGLE_CLIENT_ID_HERE`&&(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(p,{sx:{my:2}}),(0,C.jsx)(T,{})]}),(0,C.jsxs)(s,{variant:`body2`,sx:{textAlign:`center`,mt:2.5,color:`#666`},children:[`Zaten hesabın var mı? `,(0,C.jsx)(s,{component:r,to:`/login`,sx:{color:`#dc2626`,fontWeight:600,textDecoration:`none`},children:`Giriş Yap`})]})]}),(0,C.jsxs)(h,{open:D,onClose:()=>O(!1),maxWidth:`sm`,fullWidth:!0,children:[(0,C.jsx)(g,{sx:{fontWeight:700},children:`KVKK Aydınlatma Metni`}),(0,C.jsx)(u,{children:(0,C.jsx)(s,{variant:`body2`,sx:{whiteSpace:`pre-line`},children:N.kvkk_text||`Veri Sorumlusu:
Ahment Muhittin Ark ve Ulaş Kantarcı Adi Ortaklığı
Adres: Uga Burger, İnönü Mah. No:2, Yenişehir / Mersin
E-posta: bilgi@ugaburger.com

Kişisel verileriniz; sipariş süreçlerinin yürütülmesi, iletişim faaliyetlerinin sağlanması ve hukuki yükümlülüklerin yerine getirilmesi amacıyla 6698 sayılı KVKK kapsamında işlenmektedir.

Toplanan kişisel veriler: Ad, Soyad, Telefon, E-posta, Adres bilgileri.

Verileriniz yasal zorunluluklar dışında üçüncü kişilerle paylaşılmamaktadır. KVKK'nın 11. maddesi gereğince bilgi edinme, düzeltme ve silme haklarınız saklıdır.


— ÖN BİLGİLENDİRME FORMU —

Satıcı: Ahmet Muhittin Ark ve Ulaş Kantarcı Adi Ortaklığı
Adres: İnönü Mah. No:2 Yenişehir / Mersin

Sipariş konusu ürün/hizmet: Seçilen yemek ürünleri
Toplam fiyat: Sipariş ekranında belirtilmiştir (KDV dahil)
Ödeme şekli: Online ödeme / kapıda ödeme (varsa)
Teslimat süresi: Ortalama 30-60 dakika

Cayma hakkı: Gıda ürünlerinde cayma hakkı bulunmamaktadır.

Fatura Bilgisi:
Verilen tüm siparişler için 213 sayılı Vergi Usul Kanunu uyarınca e-arşiv fatura düzenlenmekte olup, müşterinin sipariş sırasında belirttiği e-posta adresine gönderilmektedir.

Alıcı, siparişi onaylayarak yukarıdaki bilgileri okuduğunu, anladığını ve kabul ettiğini beyan eder.`})}),(0,C.jsx)(d,{children:(0,C.jsx)(_,{onClick:()=>{E(!0),O(!1)},variant:`contained`,sx:{fontWeight:600},children:`Okudum, Kabul Ediyorum`})})]}),(0,C.jsxs)(h,{open:k,onClose:()=>A(!1),maxWidth:`sm`,fullWidth:!0,children:[(0,C.jsx)(g,{sx:{fontWeight:700},children:`Gizlilik Politikası`}),(0,C.jsx)(u,{children:(0,C.jsx)(s,{variant:`body2`,sx:{whiteSpace:`pre-line`},children:N.privacy_text||`Uga Burger olarak kişisel verilerinizin güvenliğini önemsiyoruz.

Toplanan bilgiler yalnızca sipariş süreçleri ve müşteri iletişimi amacıyla kullanılır. Kredi kartı bilgileriniz sunucularımızda saklanmaz.

Çerez Politikası: Sitemiz, kullanıcı deneyimini iyileştirmek için çerezler kullanmaktadır.

Bilgileriniz üçüncü taraflarla paylaşılmaz ve yasal gereklilikler dışında kullanılmaz.`})}),(0,C.jsx)(d,{children:(0,C.jsx)(_,{onClick:()=>A(!1),variant:`contained`,sx:{fontWeight:600},children:`Kapat`})})]}),(0,C.jsxs)(h,{open:j,onClose:()=>M(!1),maxWidth:`sm`,fullWidth:!0,children:[(0,C.jsx)(g,{sx:{fontWeight:700},children:`Mesafeli Satış Sözleşmesi`}),(0,C.jsx)(u,{children:(0,C.jsx)(s,{variant:`body2`,sx:{whiteSpace:`pre-line`},children:N.sales_agreement||`SATICI BİLGİLERİ
Satıcı: Ahment Muhittin Ark ve Ulaş Kantarcı Adi Ortaklığı
Adres: Uga Burger, İnönü Mah. No:2, Yenişehir / Mersin

Sipariş onaylandıktan sonra hazırlanmaya başlanır. Hazırlığa başlanmış siparişler iptal edilemez.

Teslimat süresi bölgeye ve yoğunluğa göre değişiklik gösterebilir.

Ödeme, sipariş onayı sonrasında tahsil edilir. İade ve cayma hakkı, tüketici mevzuatı çerçevesinde uygulanır.`})}),(0,C.jsx)(d,{children:(0,C.jsx)(_,{onClick:()=>M(!1),variant:`contained`,sx:{fontWeight:600},children:`Kapat`})})]})]})}export{E as default};