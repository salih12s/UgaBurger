const router = require('express').Router();
const { register, login, getMe, updateProfile, forgotPassword, resetPassword, resetPasswordWithCode, verifyResetCode, googleLogin } = require('../controllers/authController');
const { authMiddleware } = require('../middleware/auth');

router.post('/register', register);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/verify-reset-code', verifyResetCode);
router.post('/reset-password-with-code', resetPasswordWithCode);
router.post('/reset-password/:token', resetPassword);
router.post('/google', googleLogin);
router.get('/me', authMiddleware, getMe);
router.put('/profile', authMiddleware, updateProfile);

module.exports = router;
